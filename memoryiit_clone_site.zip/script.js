const btn = document.getElementById("startBtn");
const intro = document.getElementById("intro");
const mainContent = document.getElementById("mainContent");

btn.addEventListener("click", () => {
  intro.classList.add("hidden");
  mainContent.classList.remove("hidden");
});

const startDate = new Date("2023-01-01T00:00:00");

function updateTimer() {
  const now = new Date();
  const diff = now - startDate;

  const seconds = Math.floor(diff / 1000) % 60;
  const minutes = Math.floor(diff / (1000 * 60)) % 60;
  const hours = Math.floor(diff / (1000 * 60 * 60)) % 24;
  const daysTotal = Math.floor(diff / (1000 * 60 * 60 * 24));
  const months = Math.floor(daysTotal / 30.44);
  const years = Math.floor(months / 12);
  const monthsFinal = months % 12;
  const days = Math.floor(daysTotal % 30.44);

  document.getElementById("timer").textContent =
    `${years} anos, ${monthsFinal} meses, ${days} dias, ` +
    `${hours} horas, ${minutes} minutos e ${seconds} segundos`;
}

setInterval(updateTimer, 1000);
updateTimer();

let index = 0;
const images = document.querySelectorAll(".carousel-img");

setInterval(() => {
  images[index].classList.add("hidden");
  index = (index + 1) % images.length;
  images[index].classList.remove("hidden");
}, 3000);
